// Fetch products from FakeStore API
async function fetchProducts(category = 'all') {
    try {
        let url = 'https://fakestoreapi.com/products';
        if (category !== 'all') {
            url = `https://fakestoreapi.com/products/category/${category}`;
        }

        const response = await fetch(url);
        const products = await response.json();
        displayProducts(products);
    } catch (error) {
        console.error('Error fetching products:', error);
        document.getElementById('products-container').innerHTML =
            '<p class="error">Failed to load products. Please try again later.</p>';
    }
}


// Add this near the top of your main.js file
document.addEventListener('DOMContentLoaded', () => {
    // Existing code...

    // Set up search functionality
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');

    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', performSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }
});

// Add this new function to your main.js
async function performSearch() {
    const searchTerm = document.getElementById('search-input').value.trim().toLowerCase();

    if (!searchTerm) {
        fetchProducts();
        return;
    }

    try {
        const response = await fetch('https://fakestoreapi.com/products');
        const allProducts = await response.json();

        const filteredProducts = allProducts.filter(product =>
            product.title.toLowerCase().includes(searchTerm) ||
            product.description.toLowerCase().includes(searchTerm) ||
            product.category.toLowerCase().includes(searchTerm)
        );

        displayProducts(filteredProducts);

        if (filteredProducts.length === 0) {
            document.getElementById('products-container').innerHTML =
                '<p class="empty">No products found matching your search.</p>';
        }
    } catch (error) {
        console.error('Error searching products:', error);
        document.getElementById('products-container').innerHTML =
            '<p class="error">Failed to search products. Please try again later.</p>';
    }
}


// Display products on the page
function displayProducts(products) {
    const productsContainer = document.getElementById('products-container');

    if (!products || products.length === 0) {
        productsContainer.innerHTML = '<p class="empty">No products found.</p>';
        return;
    }

    productsContainer.innerHTML = products.map(product => `
        <div class="product-card">
            <a href="product.html?id=${product.id}">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.title}">
                </div>
            </a>
            <div class="product-info">
                <a href="product.html?id=${product.id}">
                    <h3>${product.title}</h3>
                </a>
                <p>${product.category}</p>
                <span class="product-price">$${product.price.toFixed(2)}</span>
                <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
            </div>
        </div>
    `).join('');




    // Add event listeners to all add-to-cart buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const productId = button.getAttribute('data-id');
            const product = products.find(p => p.id == productId);
            addToCart(product);
        });
    });
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    // Load all products initially
    fetchProducts();

    // Set up category filter
    const categoryFilter = document.getElementById('category-filter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', (e) => {
            fetchProducts(e.target.value);
        });
    }

    // Update cart count
    updateCartCount();
});

// Add to cart function (will be used by both main.js and product.js)
function addToCart(product, quantity = 1) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Check if product already exists in cart
    const existingItem = cart.find(item => item.id === product.id);

    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            id: product.id,
            title: product.title,
            price: product.price,
            image: product.image,
            quantity: quantity
        });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();

    // Show notification
    showNotification(`${product.title} added to cart!`);
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 10);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Notification styles (add to style.css)
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    .notification {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--primary-color);
        color: white;
        padding: 12px 24px;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        opacity: 0;
        transition: opacity 0.3s;
        z-index: 1000;
    }
    
    .notification.show {
        opacity: 1;
    }
`;
document.head.appendChild(notificationStyles);