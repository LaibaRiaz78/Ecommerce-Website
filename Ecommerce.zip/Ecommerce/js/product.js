// Fetch single product details
async function fetchProductDetails(productId) {
    try {
        const response = await fetch(`https://fakestoreapi.com/products/${productId}`);
        const product = await response.json();
        displayProductDetails(product);
    } catch (error) {
        console.error('Error fetching product details:', error);
        document.getElementById('product-detail').innerHTML = 
            '<p class="error">Failed to load product details. Please try again later.</p>';
    }
}

// Display product details on the page
function displayProductDetails(product) {
    const productDetailContainer = document.getElementById('product-detail');
    
    if (!product) {
        productDetailContainer.innerHTML = '<p class="error">Product not found.</p>';
        return;
    }
    
    // Generate star rating HTML
    const stars = '★'.repeat(Math.round(product.rating.rate)) + 
                  '☆'.repeat(5 - Math.round(product.rating.rate));
    
    productDetailContainer.innerHTML = `
        <div class="product-detail-image">
            <img src="${product.image}" alt="${product.title}">
        </div>
        <div class="product-detail-info">
            <h2>${product.title}</h2>
            <span class="product-detail-price">$${product.price.toFixed(2)}</span>
            <div class="product-detail-rating">
                <span class="stars">${stars}</span>
                <span>${product.rating.rate} (${product.rating.count} reviews)</span>
            </div>
            <p class="product-detail-description">${product.description}</p>
            <div class="quantity-selector">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" value="1">
            </div>
            <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
        </div>
    `;
    
    // Add event listener to add-to-cart button
    document.querySelector('.add-to-cart').addEventListener('click', () => {
        const quantity = parseInt(document.getElementById('quantity').value) || 1;
        addToCart(product, quantity);
    });
}

// Add product to cart
function addToCart(product, quantity) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Check if product already exists in cart
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            id: product.id,
            title: product.title,
            price: product.price,
            image: product.image,
            quantity: quantity
        });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    
    // Show notification
    showNotification(`${product.title} added to cart!`);
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 10);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Update cart count in header
function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    document.querySelector('.cart-count').textContent = totalItems;
}

// Add notification styles
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    .notification {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--primary-color);
        color: white;
        padding: 12px 24px;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        opacity: 0;
        transition: opacity 0.3s;
        z-index: 1000;
    }
    
    .notification.show {
        opacity: 1;
    }
`;
document.head.appendChild(notificationStyles);

// Initialize the product page
document.addEventListener('DOMContentLoaded', () => {
    // Get product ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    
    if (productId) {
        fetchProductDetails(productId);
    } else {
        document.getElementById('product-detail').innerHTML = 
            '<p class="error">No product specified.</p>';
    }
    
    // Update cart count
    updateCartCount();
});