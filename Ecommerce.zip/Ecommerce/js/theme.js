
document.addEventListener('DOMContentLoaded', () => {
    // Initialize theme on page load
    initTheme();

    // Set up theme toggle button 
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', toggleTheme);
    }
});

// Initialize theme from localStorage
function initTheme() {
    const savedTheme = getSavedTheme();
    applyTheme(savedTheme);
}

// Get theme from localStorage with fallback to lightTheme
function getSavedTheme() {
    try {
        return localStorage.getItem('theme') || 'light';
    } catch (e) {
        return 'light';
    }
}


// Apply theme to the document
function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    updateThemeButton(theme);
    updateThemeInLocalStorage(theme);
}

// Update localStorage with current theme
function updateThemeInLocalStorage(theme) {
    try {
        localStorage.setItem('theme', theme);
    } catch (e) {
        console.error('Failed to save theme preference:', e);
    }
}

// Update theme toggle button text
function updateThemeButton(theme) {
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    if (themeToggleBtn) {
        themeToggleBtn.textContent = theme === 'light'
            ? 'Switch to Dark Mode'
            : 'Switch to Light Mode';
    }
}

// Toggle between light and dark themes
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(newTheme);
}

// Page transitions (for SPA-like behavior)
window.addEventListener('pageshow', (event) => {
    if (event.persisted) {
        initTheme();
    }
});


